const stations = [
  {name:'Paradise Main', genre:'Eclectic · World', cat:'dance', initials:'RP', color:'linear-gradient(135deg,#6252d8,#bc62a8)', stream:'https://stream.radioparadise.com/mp3-192'},
  {name:'Paradise Mellow', genre:'Mellow · Relax', cat:'chill', initials:'PM', color:'linear-gradient(135deg,#163957,#3ca1a3)', stream:'https://stream.radioparadise.com/mellow-192'},
  {name:'Paradise Rock', genre:'Rock · Alternative', cat:'rock', initials:'PR', color:'linear-gradient(135deg,#692f37,#e48655)', stream:'https://stream.radioparadise.com/rock-192'},
  {name:'Paradise Global', genre:'World · Global', cat:'dance', initials:'PG', color:'linear-gradient(135deg,#24539c,#e96a9a)', stream:'https://stream.radioparadise.com/global-192'},
  {name:'KEXP 90.3 FM', genre:'Indie · Eclectic', cat:'rock', initials:'KX', color:'linear-gradient(135deg,#b05c21,#efbd5a)', stream:'https://kexp.streamguys1.com/kexp160.aac'},
  {name:'Chilltrax', genre:'Downtempo · Chill', cat:'chill', initials:'CH', color:'linear-gradient(135deg,#3b235f,#8e58d2)', stream:'https://streamssl.chilltrax.com/'},
  {name:'Radio Record', genre:'Dance · Hits', cat:'dance', region:'ru', initials:'RR', stream:'https://radiorecord.hostingradio.ru/rr_main96.aacp'},
  {name:'Russian Mix', genre:'Русские танцевальные хиты', cat:'dance', region:'ru', initials:'RM', stream:'https://radiorecord.hostingradio.ru/rus96.aacp'},
  {name:'Russian Hits', genre:'Русские хиты', cat:'dance', region:'ru', initials:'RH', stream:'https://radiorecord.hostingradio.ru/russianhits96.aacp'},
  {name:'Супердискотека 90-х', genre:'Русское ретро · 90-е', cat:'retro', region:'ru', initials:'90', stream:'https://radiorecord.hostingradio.ru/sd9096.aacp'},
  {name:'Record Chill-Out', genre:'Chill-Out · Relax', cat:'chill', region:'ru', initials:'CO', stream:'https://radiorecord.hostingradio.ru/chil96.aacp'},
  {name:'Record Deep', genre:'Deep House', cat:'dance', region:'ru', initials:'DP', stream:'https://radiorecord.hostingradio.ru/deep96.aacp'},
  {name:'Record Megamix', genre:'Dance · Megamix', cat:'dance', region:'ru', initials:'MX', stream:'https://radiorecord.hostingradio.ru/mix96.aacp'},
  {name:'Record Remix', genre:'Remix · Dance', cat:'dance', region:'ru', initials:'RX', stream:'https://radiorecord.hostingradio.ru/rmx96.aacp'},
  {name:'Рекорд 00-х', genre:'Хиты нулевых', cat:'retro', region:'ru', initials:'00', stream:'https://radiorecord.hostingradio.ru/200096.aacp'},
  {name:'Big Hits', genre:'Главные хиты', cat:'dance', region:'ru', initials:'BH', stream:'https://radiorecord.hostingradio.ru/bighits96.aacp'},
  {name:'Chill House', genre:'Chill · House', cat:'chill', region:'ru', initials:'CH', stream:'https://radiorecord.hostingradio.ru/chillhouse96.aacp'},
  {name:'Trancemission', genre:'Trance', cat:'dance', region:'ru', initials:'TM', stream:'https://radiorecord.hostingradio.ru/tm96.aacp'},
  {name:'Record 80-х', genre:'Dance · 80-е', cat:'retro', region:'ru', initials:'80', stream:'https://radiorecord.hostingradio.ru/198096.aacp'},
  {name:'Record Rock', genre:'Rock', cat:'rock', region:'ru', initials:'RK', stream:'https://radiorecord.hostingradio.ru/rock96.aacp'},
  {name:'Russian Gold', genre:'Золотые русские хиты', cat:'retro', region:'ru', initials:'RG', stream:'https://radiorecord.hostingradio.ru/russiangold96.aacp'},
  {name:'Pirate Station', genre:"Drum'n'Bass", cat:'bass', region:'ru', initials:'PS', stream:'https://radiorecord.hostingradio.ru/ps96.aacp'},
  {name:'Record Gold', genre:'Золотые танцевальные хиты', cat:'retro', region:'ru', initials:'GD', stream:'https://radiorecord.hostingradio.ru/gold96.aacp'},
  {name:'На Хайпе', genre:'Русские новинки', cat:'rap', region:'ru', initials:'HX', stream:'https://radiorecord.hostingradio.ru/hype96.aacp'},
  {name:'Record Phonk', genre:'Phonk', cat:'bass', region:'ru', initials:'PH', stream:'https://radiorecord.hostingradio.ru/phonk96.aacp'},
  {name:'Руки Вверх!', genre:'Русская поп-музыка', cat:'retro', region:'ru', initials:'РВ', stream:'https://radiorecord.hostingradio.ru/rv96.aacp'},
  {name:'Rap Hits', genre:'Rap · Hip-Hop', cat:'rap', region:'ru', initials:'RH', stream:'https://radiorecord.hostingradio.ru/rap96.aacp'},
  {name:'Rap Classics', genre:'Классика рэпа', cat:'rap', region:'ru', initials:'RC', stream:'https://radiorecord.hostingradio.ru/rapclassics96.aacp'},
  {name:'Trance Classics', genre:'Классика транса', cat:'retro', region:'ru', initials:'TC', stream:'https://radiorecord.hostingradio.ru/trancehits96.aacp'},
  {name:'Bass House', genre:'Bass · House', cat:'bass', region:'ru', initials:'BS', stream:'https://radiorecord.hostingradio.ru/jackin96.aacp'},
  {name:'Record Organic', genre:'Organic House', cat:'chill', region:'ru', initials:'OR', stream:'https://radiorecord.hostingradio.ru/organic96.aacp'},
  {name:"D'n'B Classics", genre:"Drum'n'Bass Classics", cat:'bass', region:'ru', initials:'DB', stream:'https://radiorecord.hostingradio.ru/drumhits96.aacp'},
  {name:'Record EDM', genre:'EDM', cat:'dance', region:'ru', initials:'ED', stream:'https://radiorecord.hostingradio.ru/club96.aacp'},
  {name:'Record Lo-Fi', genre:'Lo-Fi · Relax', cat:'chill', region:'ru', initials:'LF', stream:'https://radiorecord.hostingradio.ru/lofi96.aacp'},
  {name:'Neurofunk', genre:'Neurofunk · DnB', cat:'bass', region:'ru', initials:'NF', stream:'https://radiorecord.hostingradio.ru/neurofunk96.aacp'},
  {name:'Tech House', genre:'Tech House', cat:'dance', region:'ru', initials:'TH', stream:'https://radiorecord.hostingradio.ru/techouse96.aacp'},
  {name:'Record Trap', genre:'Trap', cat:'bass', region:'ru', initials:'TR', stream:'https://radiorecord.hostingradio.ru/trap96.aacp'},
  {name:'Liquid Funk', genre:'Liquid Funk · DnB', cat:'bass', region:'ru', initials:'LQ', stream:'https://radiorecord.hostingradio.ru/liquidfunk96.aacp'},
  {name:'Record Dubstep', genre:'Dubstep', cat:'bass', region:'ru', initials:'DS', stream:'https://radiorecord.hostingradio.ru/dub96.aacp'},
  {name:'House Hits', genre:'House · Hits', cat:'dance', region:'ru', initials:'HH', stream:'https://radiorecord.hostingradio.ru/househits96.aacp'},
  {name:'GOA/PSY', genre:'Psytrance · Goa', cat:'dance', region:'ru', initials:'GP', stream:'https://radiorecord.hostingradio.ru/goa96.aacp'},
  {name:'Record Ambient', genre:'Ambient · Relax', cat:'chill', region:'ru', initials:'AM', stream:'https://radiorecord.hostingradio.ru/ambient96.aacp'},
  {name:'Record Techno', genre:'Techno', cat:'dance', region:'ru', initials:'TN', stream:'https://radiorecord.hostingradio.ru/techno96.aacp'},
  {name:'Synthwave', genre:'Synthwave · Retro', cat:'retro', region:'ru', initials:'SW', stream:'https://radiorecord.hostingradio.ru/synth96.aacp'},
  {name:'Гоп FM', genre:'Русский юмор · Dance', cat:'retro', region:'ru', initials:'ГФ', stream:'https://radiorecord.hostingradio.ru/gop96.aacp'},
  {name:'Медляк FM', genre:'Русские медленные хиты', cat:'chill', region:'ru', initials:'МФ', stream:'https://radiorecord.hostingradio.ru/mdl96.aacp'}
];
const palettes=['linear-gradient(135deg,#6d4ee8,#c35f9f)','linear-gradient(135deg,#0e7783,#49b8a5)','linear-gradient(135deg,#b14949,#ec8b58)','linear-gradient(135deg,#28549c,#a26ed4)','linear-gradient(135deg,#bd7623,#f0c14c)','linear-gradient(135deg,#263c62,#5977bf)','linear-gradient(135deg,#4e2f72,#aa58c7)','linear-gradient(135deg,#185f4a,#5ebf84)'];
const stationColor=(s,i)=>s.color||palettes[i%palettes.length];
const audio=document.querySelector('#audio'), grid=document.querySelector('#stationGrid'), playBtn=document.querySelector('#playBtn'), statusText=document.querySelector('#statusText'), statusDot=document.querySelector('#statusDot'); let current=-1;
function render(){grid.innerHTML=stations.map((s,i)=>`<article class="station-card" data-cat="${s.cat}" data-region="${s.region||'world'}" data-index="${i}" data-search="${(s.name+' '+s.genre).toLowerCase()}"><div class="cover" style="background:${stationColor(s,i)}"><strong>${s.initials}</strong></div><span class="tag">${s.region==='ru'?'RU · LIVE':'LIVE'}</span><button class="card-play" aria-label="Включить ${s.name}">▶</button><h3>${s.name}</h3><p>${s.genre}</p></article>`).join('');grid.querySelectorAll('.station-card').forEach(c=>c.querySelector('button').onclick=()=>select(+c.dataset.index));applyCatalog()}
function select(i){if(current===i&&!audio.paused){audio.pause();return}current=i;const s=stations[i];audio.src=s.stream;document.querySelector('#playerName').textContent=s.name;document.querySelector('#playerGenre').textContent=s.genre;const pc=document.querySelector('#playerCover');pc.textContent=s.initials;pc.style.background=stationColor(s,i);statusText.textContent='Подключаемся…';statusDot.classList.remove('live');if('mediaSession'in navigator)navigator.mediaSession.metadata=new MediaMetadata({title:s.name,artist:s.genre,album:'AntiLTE radio'});audio.play().catch(()=>toast('Нажмите Play ещё раз, чтобы разрешить воспроизведение'));updateCards()}
function updateCards(){grid.querySelectorAll('.station-card').forEach((c,i)=>{c.classList.toggle('playing',i===current&&!audio.paused);c.querySelector('button').textContent=i===current&&!audio.paused?'Ⅱ':'▶'});playBtn.textContent=audio.paused?'▶':'Ⅱ'}
audio.addEventListener('playing',()=>{statusText.textContent='Прямой эфир';statusDot.classList.add('live');updateCards()});audio.addEventListener('pause',updateCards);audio.addEventListener('waiting',()=>statusText.textContent='Буферизация…');audio.addEventListener('error',()=>{statusText.textContent='Поток временно недоступен';statusDot.classList.remove('live');toast('Эта станция сейчас недоступна. Попробуйте другую.')});
playBtn.onclick=()=>current<0?select(0):audio.paused?audio.play():audio.pause();document.querySelector('#prevBtn').onclick=()=>select((current-1+stations.length)%stations.length);document.querySelector('#nextBtn').onclick=()=>select((current+1)%stations.length);document.querySelectorAll('[data-play-featured]').forEach(b=>b.onclick=()=>select(0));
const volume=document.querySelector('#volume');const rawVolume=localStorage.getItem('neder-volume');const savedVolume=rawVolume===null?NaN:Number(rawVolume);audio.volume=Number.isFinite(savedVolume)&&savedVolume>=0&&savedVolume<=1?savedVolume:.75;volume.value=audio.volume;volume.oninput=()=>{audio.volume=+volume.value;localStorage.setItem('neder-volume',volume.value)};document.querySelector('#muteBtn').onclick=e=>{audio.muted=!audio.muted;e.currentTarget.textContent=audio.muted?'🔇':'🔊'};
let activeFilter='all';const search=document.querySelector('#stationSearch');function applyCatalog(){const query=(search?.value||'').trim().toLowerCase();grid.querySelectorAll('.station-card').forEach(c=>{const filterOk=activeFilter==='all'||(activeFilter==='russian'?c.dataset.region==='ru':c.dataset.cat===activeFilter);const searchOk=!query||c.dataset.search.includes(query);c.classList.toggle('hidden',!(filterOk&&searchOk))})}document.querySelectorAll('[data-filter]').forEach(b=>b.onclick=()=>{document.querySelectorAll('[data-filter]').forEach(x=>x.classList.remove('active'));b.classList.add('active');activeFilter=b.dataset.filter;applyCatalog()});search.addEventListener('input',applyCatalog);
function toast(text){const old=document.querySelector('.toast');if(old)old.remove();const el=document.createElement('div');el.className='toast';el.textContent=text;document.body.append(el);setTimeout(()=>el.remove(),4500)}render();
if('mediaSession'in navigator){navigator.mediaSession.setActionHandler('play',()=>audio.play());navigator.mediaSession.setActionHandler('pause',()=>audio.pause());navigator.mediaSession.setActionHandler('previoustrack',()=>select((current-1+stations.length)%stations.length));navigator.mediaSession.setActionHandler('nexttrack',()=>select((current+1)%stations.length))}
